"""API module for Fulmine-Spark."""
