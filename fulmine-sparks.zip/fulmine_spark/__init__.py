"""Fulmine-Spark: Lightning-powered AI image generation service."""

__version__ = "1.0.0"
__author__ = "Fulmine Labs"
__description__ = "Lightning-powered AI image generation service"
